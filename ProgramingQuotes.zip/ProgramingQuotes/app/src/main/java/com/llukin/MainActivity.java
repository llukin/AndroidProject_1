package com.llukin;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements AdapterListe.ItemClickInterface {

    private AdapterListe adapterListe;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapterListe = new AdapterListe(this);
        adapterListe.setClickListener(this);
        recyclerView.setAdapter(adapterListe);
        recyclerView.addItemDecoration(new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL));

        ucitaj();

    }


    private void ucitaj() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://programming-quotes-api.herokuapp.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        QuoteSucelje quoteSucelje = retrofit.create(QuoteSucelje.class);
        Call<List<Quote>> call = quoteSucelje.dohvatiQuote();

        call.enqueue(new Callback<List<Quote>>() {
            @Override
            public void onResponse(Call<List<Quote>> call, Response<List<Quote>> response) {
                if (!response.isSuccessful()) {
                    return;

                }

                Quotes quotes = new Quotes();
                quotes.setQuoteList(response.body());
                adapterListe.setQuotes(quotes.getQuoteList());
                adapterListe.notifyDataSetChanged();

            }

            @Override
            public void onFailure(Call<List<Quote>> call, Throwable t) {
                Log.d("aaaaaaaaaaaa", t.toString());
            }

        });

    }

    @Override
    public void onItemClick(View view, int position) {

        Quote quote = adapterListe.getQuote(position);
        Intent intent = new Intent(this, SecondActivity.class);
        intent.putExtra("quote", quote);
        startActivity(intent);

    }
}
