package com.llukin;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface QuoteSucelje {

    @GET("/quotes/page/1")
    Call<List<Quote>>  dohvatiQuote();
}
