package com.llukin;

import java.io.Serializable;
import java.util.List;

public class Quotes implements Serializable {

    private List<Quote> quoteList;

    public Quotes() {

    }

    public List<Quote> getQuoteList() {
        return quoteList;
    }

    public void setQuoteList(List<Quote> quoteList) {
        this.quoteList = quoteList;
    }
}
