package com.llukin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.second_activity);

        TextView author = findViewById(R.id.author);
        TextView quoteTxt = findViewById(R.id.quote);
        Button back = findViewById(R.id.back);

        Intent intent = getIntent();
        Quote quote = (Quote) intent.getSerializableExtra("quote");

        if (quote != null) {
            if (quote.getAuthor() != null) author.setText(quote.getAuthor());
            if (quote.getEn() != null) quoteTxt.setText(quote.getEn());
        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
